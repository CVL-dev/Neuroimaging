#ifndef __SUT__HEADER__
#define __SUT__HEADER__

static char rcsID_Sut_h[] = "$Id: Sut.h,v 1.1 1994/08/10 19:19:29 smm Exp $";


#include "SutProto.h"
#include "SutList.h"

#endif
