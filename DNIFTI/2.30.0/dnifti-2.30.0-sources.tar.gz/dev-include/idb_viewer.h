typedef struct {
    void *reserved[2];
    IDB_Query query;
}   QUERY_LIST_ITEM;
