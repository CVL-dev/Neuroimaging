/* Menu items in Windows Display Application */

/*#define IDM_OPEN	100*/
/*#define	IDM_CLOSE	200*/
#define	IDM_EXIT	300
