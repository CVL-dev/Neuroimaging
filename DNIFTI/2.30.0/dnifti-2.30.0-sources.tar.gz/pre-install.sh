#!/bin/bash
rm -rf /etc/profile.d/dnifti_modules.sh &>> /dev/null
exit 0
