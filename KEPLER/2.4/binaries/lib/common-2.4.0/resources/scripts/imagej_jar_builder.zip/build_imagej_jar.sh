mkdir build
cd build
curl -o ij143u-src.zip http://rsbweb.nih.gov/ij/download/src/ij143u-src.zip
# MD5 hash of ij143u-src.zip is 4b052d44dc6dbb6fa81efeeb565ea0b7
unzip ij143u-src.zip
cd source
patch --verbose ij/Prefs.java ../../Prefs.patch
ant build
mv ij.jar ../
