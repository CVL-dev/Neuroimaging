#!/bin/bash
rm -rf /etc/profile.d/minc_modules.sh &>> /dev/null
exit 0
