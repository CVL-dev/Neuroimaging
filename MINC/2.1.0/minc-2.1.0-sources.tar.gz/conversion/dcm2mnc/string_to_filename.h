extern void string_to_filename(const char *string, char *filename, int maxlen);
extern void string_to_initials(char *string, char *filename, int maxlen);
