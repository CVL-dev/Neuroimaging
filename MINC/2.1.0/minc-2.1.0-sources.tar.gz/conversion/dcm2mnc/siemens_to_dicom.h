extern Acr_Group siemens_to_dicom(const char *filename, int max_group);
extern void update_coordinate_info(Acr_Group group_list);

