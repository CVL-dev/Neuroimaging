
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NAN = 258,
     IN = 259,
     TO = 260,
     IDENT = 261,
     REAL = 262,
     AVG = 263,
     PROD = 264,
     SUM = 265,
     LET = 266,
     NEG = 267,
     LEN = 268,
     MAX = 269,
     MIN = 270,
     ISNAN = 271,
     SQRT = 272,
     ABS = 273,
     EXP = 274,
     LOG = 275,
     SIN = 276,
     COS = 277,
     TAN = 278,
     ASIN = 279,
     ACOS = 280,
     ATAN = 281,
     CLAMP = 282,
     SEGMENT = 283,
     LT = 284,
     LE = 285,
     GT = 286,
     GE = 287,
     EQ = 288,
     NE = 289,
     NOT = 290,
     AND = 291,
     OR = 292,
     IF = 293,
     ELSE = 294,
     FOR = 295
   };
#endif
/* Tokens.  */
#define NAN 258
#define IN 259
#define TO 260
#define IDENT 261
#define REAL 262
#define AVG 263
#define PROD 264
#define SUM 265
#define LET 266
#define NEG 267
#define LEN 268
#define MAX 269
#define MIN 270
#define ISNAN 271
#define SQRT 272
#define ABS 273
#define EXP 274
#define LOG 275
#define SIN 276
#define COS 277
#define TAN 278
#define ASIN 279
#define ACOS 280
#define ATAN 281
#define CLAMP 282
#define SEGMENT 283
#define LT 284
#define LE 285
#define GT 286
#define GE 287
#define EQ 288
#define NE 289
#define NOT 290
#define AND 291
#define OR 292
#define IF 293
#define ELSE 294
#define FOR 295




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 15 "gram.y"

int      pos;
node_t   node;
double   real;
ident_t  ident;



/* Line 1676 of yacc.c  */
#line 141 "progs/minccalc/gram.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


