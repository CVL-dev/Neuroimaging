#!/bin/bash
rm -rf /etc/profile.d/mrtrix_modules.sh &>> /dev/null
exit 0
