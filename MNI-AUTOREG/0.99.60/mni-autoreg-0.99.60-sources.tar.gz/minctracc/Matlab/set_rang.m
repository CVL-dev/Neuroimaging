function data = set_rang(data,start,done,val)

for j=start:done,
  data(j) = val;
end

