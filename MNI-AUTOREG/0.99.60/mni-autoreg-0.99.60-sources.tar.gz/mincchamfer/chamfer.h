/* ----------------------------- MNI Header -----------------------------------
@NAME       : chamfer.h
@DESCRIPTION: prototypes for chamfer.c
@CREATED    : Nov 2, 1998 - louis
@MODIFIED   : 
---------------------------------------------------------------------------- */

VIO_Status compute_chamfer(VIO_Volume  chamfer, VIO_Real max_val);
