#!/bin/bash
rm -rf /etc/profile.d/mni_autoreg_modules.sh &>> /dev/null
exit 0
